Action1()
{

	lr_start_transaction("1_Register");

	web_add_cookie("__utmb=78382081.8.10.1790859245; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmc=78382081; DOMAIN=demowebshop.tricentis.com");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	lr_think_time(12);

	web_url("register", 
		"URL=https://demowebshop.tricentis.com/register", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("__utmb=78382081.9.10.1790859245; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("register_2", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t5.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=5lAJnFVAhVCilVT5LKZIWYEl7xwme4Mmn_SOqKIomJK-cEy-4PYCpAAS1KOOHbtR6ou34HNtyEKNpJ2vzu-acQ0We-Wyyj3XFk0j3dgl3wg1", ENDITEM, 
		"Name=Gender", "Value=M", ENDITEM, 
		"Name=FirstName", "Value=k", ENDITEM, 
		"Name=LastName", "Value=v", ENDITEM, 
		"Name=Email", "Value=himuvarunnn@gmail.com", ENDITEM, 
		"Name=Password", "Value=Password@123", ENDITEM, 
		"Name=ConfirmPassword", "Value=Password@123", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_add_cookie("__utmb=78382081.10.10.1790859245; DOMAIN=demowebshop.tricentis.com");

	web_url("Tricentis Demo Web Shop", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/registerresult/1", 
		"Snapshot=t6.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("__utmb=78382081.11.10.1790859245; DOMAIN=demowebshop.tricentis.com");

	lr_end_transaction("1_Register",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("2_Category");

	web_url("Books", 
		"URL=https://demowebshop.tricentis.com/books", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t7.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("__utmb=78382081.12.10.1790859245; DOMAIN=demowebshop.tricentis.com");

	lr_end_transaction("2_Category",LR_AUTO);

	lr_think_time(16);

	lr_start_transaction("3_Item");

	web_url("Fiction", 
		"URL=https://demowebshop.tricentis.com/fiction", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/books", 
		"Snapshot=t8.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("3_Item",LR_AUTO);

	lr_start_transaction("4_AddToCart");

	web_add_cookie("__utmb=78382081.13.10.1790859245; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(16);

	web_submit_data("1", 
		"Action=https://demowebshop.tricentis.com/addproducttocart/details/45/1", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/fiction", 
		"Snapshot=t9.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=addtocart_45.EnteredQuantity", "Value=1", ENDITEM, 
		LAST);

	lr_end_transaction("4_AddToCart",LR_AUTO);

	lr_think_time(14);

	lr_start_transaction("5_ShipplingCart");

	web_url("cart", 
		"URL=https://demowebshop.tricentis.com/cart", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/fiction", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("5_ShipplingCart",LR_AUTO);

	lr_start_transaction("6_Checkout");

	web_add_cookie("__utmb=78382081.14.10.1790859245; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=itemquantity7122488", "Value=2", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=0", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value=", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		LAST);

	lr_end_transaction("6_Checkout",LR_AUTO);

	lr_start_transaction("7_Billing");

	web_add_cookie("__utmb=78382081.15.10.1790859245; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(17);

	web_url("getstatesbycountryid", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true&_=1790859577101", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t12.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("top-menu-list-image-hover.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-list-image-hover.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t13.inf", 
		LAST);

	lr_think_time(23);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value=k", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value=v", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value=himuvarunnn@gmail.com", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value=", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value=41", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.City", "Value=ballari", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value=ballari", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value=123456", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value=9887654321", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
		LAST);

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5160135", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value=k", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value=v", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value=himuvarunnn@gmail.com", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	web_submit_data("OpcSaveShippingMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t16.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=shippingoption", "Value=Ground___Shipping.FixedRate", ENDITEM, 
		LAST);

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t17.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.CashOnDelivery", ENDITEM, 
		LAST);

	web_custom_request("OpcSavePaymentInfo", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t18.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	lr_end_transaction("7_Billing",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("8_Confirm");

	web_custom_request("OpcConfirmOrder", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t19.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	web_url("completed", 
		"URL=https://demowebshop.tricentis.com/checkout/completed/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t20.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("8_Confirm",LR_AUTO);

	return 0;
}