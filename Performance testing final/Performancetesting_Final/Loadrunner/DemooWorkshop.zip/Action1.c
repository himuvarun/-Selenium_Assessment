Action1()
{
    lr_start_transaction("1_Register");

    web_add_auto_header("Accept-Language", "en-US,en;q=0.9");

    lr_think_time(12);

    /* Capture registration verification token */
    web_reg_save_param_regexp(
        "ParamName=c_token",
        "RegExp=name=\"__RequestVerificationToken\" type=\"hidden\" value=\"([^\"]+)\"",
        "Group=1",
        "Ordinal=1",
        LAST);

    web_url("register",
        "URL=https://demowebshop.tricentis.com/register",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/",
        "Mode=HTTP",
        LAST);

    web_submit_data("register_2",
        "Action=https://demowebshop.tricentis.com/register",
        "Method=POST",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/register",
        "Mode=HTTP",
        ITEMDATA,
        "Name=__RequestVerificationToken", "Value={c_token}", ENDITEM,
        "Name=Gender", "Value={P_Gender}", ENDITEM,
        "Name=FirstName", "Value={P_FirstName}", ENDITEM,
        "Name=LastName", "Value={P_Lastname}", ENDITEM,
        "Name=Email", "Value={P_Email}", ENDITEM,
        "Name=Password", "Value={P_Password}", ENDITEM,
        "Name=ConfirmPassword", "Value={P_ConfirmPassword}", ENDITEM,
        "Name=register-button", "Value=Register", ENDITEM,
        LAST);

    /* Capture Books link from homepage */
    web_reg_save_param_regexp(
        "ParamName=c_category",
        "RegExp=href=\"/(books)\"",
        "Group=1",
        "Ordinal=1",
        LAST);

    web_url("Tricentis Demo Web Shop",
        "URL=https://demowebshop.tricentis.com/",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/register",
        "Mode=HTTP",
        LAST);

    lr_end_transaction("1_Register", LR_AUTO);

    lr_think_time(13);

    /* CATEGORY */

    lr_start_transaction("2_Category");

    /* Capture product link from Books page */
    web_reg_save_param_regexp(
        "ParamName=P_product",
        "RegExp=href=\"/(fiction)\"",
        "Group=1",
        "Ordinal=1",
        LAST);

    web_url("Books",
        "URL=https://demowebshop.tricentis.com/{c_category}",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/",
        "Mode=HTTP",
        LAST);

    lr_end_transaction("2_Category", LR_AUTO);

    lr_think_time(16);

    /* PRODUCT */

    lr_start_transaction("3_Item");

    web_url("Fiction",
        "URL=https://demowebshop.tricentis.com/{P_product}",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/{c_category}",
        "Mode=HTTP",
        LAST);

    lr_end_transaction("3_Item", LR_AUTO);

    lr_think_time(16);

    /* ADD TO CART */

    lr_start_transaction("4_AddToCart");

    /*
       Replace product ID 45 with the actual product ID
       captured from the product page response.
    */

    web_submit_data("AddToCart",
        "Action=https://demowebshop.tricentis.com/addproducttocart/details/45/1",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/{P_product}",
        "Mode=HTTP",
        ITEMDATA,
        "Name=addtocart_45.EnteredQuantity", "Value=1", ENDITEM,
        LAST);

    lr_end_transaction("4_AddToCart", LR_AUTO);

    lr_think_time(14);

    /* CART */

    lr_start_transaction("5_ShoppingCart");

    web_url("cart",
        "URL=https://demowebshop.tricentis.com/cart",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/{P_product}",
        "Mode=HTTP",
        LAST);

    lr_end_transaction("5_ShoppingCart", LR_AUTO);

    /* CHECKOUT */

    lr_start_transaction("6_Checkout");

    /*
       The itemquantity ID below is from your recording.
       Correlate it from the cart response before replay.
    */

    web_submit_data("cart_2",
        "Action=https://demowebshop.tricentis.com/cart",
        "Method=POST",
        "EncType=multipart/form-data",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/cart",
        "Mode=HTTP",
        ITEMDATA,
        "Name=itemquantity7122488", "Value=2", ENDITEM,
        "Name=discountcouponcode", "Value=", ENDITEM,
        "Name=giftcardcouponcode", "Value=", ENDITEM,
        "Name=CountryId", "Value=0", ENDITEM,
        "Name=StateProvinceId", "Value=0", ENDITEM,
        "Name=ZipPostalCode", "Value=", ENDITEM,
        "Name=termsofservice", "Value=on", ENDITEM,
        "Name=checkout", "Value=checkout", ENDITEM,
        LAST);

    lr_end_transaction("6_Checkout", LR_AUTO);

    lr_think_time(17);

    /* BILLING */

    lr_start_transaction("7_Billing");

    web_url("getstatesbycountryid",
        "URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true",
        "Resource=0",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        LAST);

    web_submit_data("OpcSaveBilling",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        ITEMDATA,
        "Name=BillingNewAddress.Id", "Value=0", ENDITEM,
        "Name=BillingNewAddress.FirstName", "Value={P_FirstName}", ENDITEM,
        "Name=BillingNewAddress.LastName", "Value={P_Lastname}", ENDITEM,
        "Name=BillingNewAddress.Email", "Value={P_Email}", ENDITEM,
        "Name=BillingNewAddress.Company", "Value=", ENDITEM,
        "Name=BillingNewAddress.CountryId", "Value=41", ENDITEM,
        "Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM,
        "Name=BillingNewAddress.City", "Value={P_city}", ENDITEM,
        "Name=BillingNewAddress.Address1", "Value={P_address1}", ENDITEM,
        "Name=BillingNewAddress.Address2", "Value=", ENDITEM,
        "Name=BillingNewAddress.ZipPostalCode", "Value=123456", ENDITEM,
        "Name=BillingNewAddress.PhoneNumber", "Value={P_phoneno}", ENDITEM,
        "Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM,
        LAST);

    /* SHIPPING */

    web_submit_data("OpcSaveShipping",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        ITEMDATA,
        "Name=shipping_address_id", "Value=5160135", ENDITEM,
        "Name=ShippingNewAddress.Id", "Value=0", ENDITEM,
        "Name=ShippingNewAddress.FirstName", "Value={P_FirstName}", ENDITEM,
        "Name=ShippingNewAddress.LastName", "Value={P_Lastname}", ENDITEM,
        "Name=ShippingNewAddress.Email", "Value={P_Email}", ENDITEM,
        "Name=ShippingNewAddress.Company", "Value=", ENDITEM,
        "Name=ShippingNewAddress.CountryId", "Value=41", ENDITEM,
        "Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM,
        "Name=ShippingNewAddress.City", "Value={P_city}", ENDITEM,
        "Name=ShippingNewAddress.Address1", "Value={P_address1}", ENDITEM,
        "Name=ShippingNewAddress.Address2", "Value=", ENDITEM,
        "Name=ShippingNewAddress.ZipPostalCode", "Value=123456", ENDITEM,
        "Name=ShippingNewAddress.PhoneNumber", "Value={P_phoneno}", ENDITEM,
        "Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM,
        "Name=PickUpInStore", "Value=false", ENDITEM,
        LAST);

    /* SHIPPING METHOD */

    web_submit_data("OpcSaveShippingMethod",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        ITEMDATA,
        "Name=shippingoption", "Value=Ground___Shipping.FixedRate", ENDITEM,
        LAST);

    /* PAYMENT METHOD */

    web_submit_data("OpcSavePaymentMethod",
        "Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/",
        "Method=POST",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        ITEMDATA,
        "Name=paymentmethod", "Value=Payments.CashOnDelivery", ENDITEM,
        LAST);

    web_custom_request("OpcSavePaymentInfo",
        "URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/",
        "Method=POST",
        "Resource=0",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        LAST);

    lr_end_transaction("7_Billing", LR_AUTO);

    lr_think_time(13);

    /* CONFIRM ORDER */

    lr_start_transaction("8_Confirm");

    web_custom_request("OpcConfirmOrder",
        "URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/",
        "Method=POST",
        "Resource=0",
        "RecContentType=application/json",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        LAST);

    web_url("completed",
        "URL=https://demowebshop.tricentis.com/checkout/completed/",
        "Resource=0",
        "RecContentType=text/html",
        "Referer=https://demowebshop.tricentis.com/onepagecheckout",
        "Mode=HTTP",
        LAST);

    lr_end_transaction("8_Confirm", LR_AUTO);

    return 0;
}